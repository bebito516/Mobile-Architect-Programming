package com.zybooks.anthonymirandaaponte_3;

import android.content.ContentValues;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.Cursor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class WeightDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "weight_Database.db";
    private static final int VERSION  = 1;

    public WeightDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class WeightTable {
        // Table and Columns
        public static final String TABLE = "weight_Table";
        public static final String COL_ID = "id";
        public static final String COL_DATE = "date";
        public static final String COL_WEIGHT = "weight";
    }
    // Structure Goal Weight
    private static final class GoalTable {
        public static final String TABLE_GOAL = "goal_Table";
        public static final String Col_GOAL_ID = "id";
        public static final String Col_GOAL_WEIGHT = "goal_weight";
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create a table when the database is active
        db.execSQL("CREATE TABLE " + WeightTable.TABLE + " (" +
                WeightTable.COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                WeightTable.COL_DATE +" TEXT, " +
                WeightTable.COL_WEIGHT + " REAL); ");

        // Create goal table
        db.execSQL("CREATE TABLE " + GoalTable.TABLE_GOAL + " (" +
                GoalTable.Col_GOAL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                GoalTable.Col_GOAL_WEIGHT + " REAL);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + WeightTable.TABLE);
        // Recreate the database
        onCreate(db);
    }

    // Insert Weight and Date
    public boolean insertWeight(String date, int weight) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(WeightTable.COL_DATE, date);
        values.put(WeightTable.COL_WEIGHT, weight);

        long weight_added = db.insert(WeightTable.TABLE, null, values);
        return weight_added != -1;
    }

    // Weight Retriever
    public List<HashMap<String, String>> getWeights() {
        SQLiteDatabase db = this.getReadableDatabase();
        List<HashMap<String, String>> weightList = new ArrayList<>();

        Cursor cursor = db.rawQuery("SELECT * FROM " + WeightTable.TABLE, null);

        while (cursor.moveToNext()) {
            HashMap<String, String> entry = new HashMap<>();
            entry.put("date", cursor.getString(1));
            entry.put("weight", cursor.getString(2));
            weightList.add(entry);
        }

        cursor.close();
        return weightList;
    }

    // Update a weight by Date
    public void updateWeight(String date, int newWeight) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(WeightTable.COL_WEIGHT, newWeight);
        db.update(WeightTable.TABLE, values, WeightTable.COL_DATE + "=?", new String[]{date});
    }

    // Delete a Weight by Date
    public void deleteWeight(String date) {
        SQLiteDatabase db = getWritableDatabase();

        db.delete(WeightTable.TABLE, WeightTable.COL_DATE + "=?", new String[]{date});
    }

    // Set Goal Weight
    public boolean setGoalWeight(int goalWeight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(GoalTable.Col_GOAL_WEIGHT, goalWeight);

        // Ensure to replace previous goal weight
        db.execSQL("DELETE FROM " + GoalTable.TABLE_GOAL);
        long goal_added = db.insert(GoalTable.TABLE_GOAL, null, values);
        return goal_added != -1;
    }

    // Get Goal Weight
    public int getGoalWeight() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT " + GoalTable.Col_GOAL_WEIGHT + " FROM " + GoalTable.TABLE_GOAL, null);

        if (cursor.moveToFirst()) {
            int goal = cursor.getInt(0);
            cursor.close();
            return goal;
        }
        // Default
        return -1;
    }
}
