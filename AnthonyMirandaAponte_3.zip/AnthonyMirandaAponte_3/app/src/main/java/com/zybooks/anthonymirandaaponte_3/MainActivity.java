package com.zybooks.anthonymirandaaponte_3;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button loginButton;
    private Button createButton;
    private LoginAuthentication dbAuthenticate;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);

        // Initialize components
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        loginButton = findViewById(R.id.loginButton);
        createButton = findViewById(R.id.create_account_button);

        // Initialize DB
        dbAuthenticate = new LoginAuthentication(this);

        // Create Account Button Clink
        createButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                register();
            }
        });

        // Login Button Click
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                login();
            }
        });
    }

    private void register() {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Username and Password cannot be empty", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean successful = dbAuthenticate.createAccount(username, password);
        if (successful) {
            Toast.makeText(this, "Account created!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Account already exists", Toast.LENGTH_SHORT).show();
        }
    }

    private void login() {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        if (dbAuthenticate.checkUser(username, password)) {
            Toast.makeText(this, "Login Successful!", Toast.LENGTH_SHORT).show();

            //Redirect to Main Page
            Intent intent = new Intent(MainActivity.this, HomeScreen.class);
            startActivity(intent);
        } else {
            Toast.makeText(this, "Invalid Username or Password", Toast.LENGTH_SHORT).show();
        }
    }
}