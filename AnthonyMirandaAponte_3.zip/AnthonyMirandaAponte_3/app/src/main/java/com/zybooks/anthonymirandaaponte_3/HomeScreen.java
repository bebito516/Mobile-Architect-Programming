package com.zybooks.anthonymirandaaponte_3;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


public class HomeScreen extends AppCompatActivity {

    private WeightDatabase dbWeightLog;
    private GridView gridView;
    private EditText dailyWeightText;
    private EditText dailyDateText;

    private TextView goalDisplay;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_database);

        // Initialize components
        gridView = findViewById(R.id.gridView);
        dailyWeightText = findViewById(R.id.dailyWeightText);
        dailyDateText = findViewById(R.id.dailyDateText);
        Button addWeightButton = findViewById(R.id.addWeightButton);
        goalDisplay = findViewById(R.id.goal);


        // Initialize DB
        dbWeightLog = new WeightDatabase(this);

        // Load data from Weight Database
        loadDataGrid();

        // Display Goal Weight
       // updateGoalView();     Unavailable App crashes

        // Add Weight Button Click
        addWeightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                inputLog();
            }
        });


    }

    private void updateGoalView() {
        // Get goal weight from SQLite Database
        int goalWeight = dbWeightLog.getGoalWeight();

        if (goalWeight != -1) {
            goalDisplay.setText(goalWeight); // Update TextView
        } else {
            goalDisplay.setText(R.string.display_weight); // Default message
        }
    }

    // Load data into gridview
    private void loadDataGrid() {
       List<HashMap<String, String>> entries = dbWeightLog.getWeights();
        ArrayList<String> dataGrid = new ArrayList<>();

        // Header for grid
        dataGrid.add("Date");
        dataGrid.add("Weight");

        // Convert data to a list
        for (HashMap<String, String> entry : entries) {
           dataGrid.add(entry.get("date"));
           dataGrid.add(entry.get("weight") + " lbs");
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, dataGrid);
        gridView.setAdapter(adapter);
    }

    // Func for logging date and weight to database
    private void inputLog() {
        // change text to strings
        String date = dailyDateText.getText().toString().trim();
        String weight_String = dailyWeightText.getText().toString().trim();

        if (date.isEmpty() || weight_String.isEmpty()) {
            Toast.makeText(this, "Entry cannot be empty", Toast.LENGTH_SHORT).show();
            return;
        }

        // change weight to int
        int weight_num = Integer.parseInt(weight_String);
        // inserts date and weight into database
        boolean weight_insert = dbWeightLog.insertWeight(date, weight_num);

        // feedback messages for input
        if (weight_insert) {
            Toast.makeText(HomeScreen.this, "Weight Added!", Toast.LENGTH_SHORT).show();
            loadDataGrid();
        } else {
            Toast.makeText(HomeScreen.this, "Error", Toast.LENGTH_SHORT).show();
        }
    }


    public void onLogoutClick(View view) {
        // logout button sends user back to login screen
        Intent intent = new Intent(HomeScreen.this, MainActivity.class);
        startActivity(intent);
    }

    public void onSettingsClick(View view) {
        // settings button sends user to settings screen
        Intent intent = new Intent(HomeScreen.this, Settings.class);
        startActivity(intent);
    }
}