package com.zybooks.anthonymirandaaponte_3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class LoginAuthentication extends SQLiteOpenHelper{
    // Database Name and Version
    private static final String DATABASE_NAME = "UserDB";
    private static final int VERSION = 1;

    public LoginAuthentication(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class UserTable {
        // Table and Columns
        public static final String TABLE_USERS = "users";
        public static final String COL_ID = "id";
        public static final String COL_USERNAME = "username";
        public static final String COL_PASSWORD = "password";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create a table when the database is active
        db.execSQL("CREATE TABLE " + UserTable.TABLE_USERS + " (" +
                UserTable.COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                UserTable.COL_USERNAME +" TEXT UNIQUE, " +
                UserTable.COL_PASSWORD + " TEXT);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + UserTable.TABLE_USERS);
        onCreate(db);
    }

    // Insert User
    public boolean createAccount(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserTable.COL_USERNAME, username);
        values.put(UserTable.COL_PASSWORD, password);  // ⚠ Plain-text storage (consider hashing for security)

        long result = db.insert(UserTable.TABLE_USERS, null, values);
        return result != -1; // Returns true if insertion was successful
    }

    // Authenticate User
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + UserTable.TABLE_USERS + " WHERE " +
        UserTable.COL_USERNAME + "=? AND " + UserTable.COL_PASSWORD + "=?";
        Cursor cursor = db.rawQuery(query, new String[]{username, password});

        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }
}
