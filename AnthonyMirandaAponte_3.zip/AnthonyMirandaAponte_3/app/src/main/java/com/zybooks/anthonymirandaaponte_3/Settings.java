package com.zybooks.anthonymirandaaponte_3;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class Settings extends AppCompatActivity {

    private WeightDatabase dbWeightLog;
    private EditText goalWeightText;
    private EditText dateUpdateText;
    private EditText weightUpdateText;
    private EditText dateDeleteText;
    private Button smsRequest;
    private Button sendSMS;
    private static final int SMS_permission = 1;
    private final String phoneNum = "8035285675";
    private final String message = "Hello! This is a test SMS from my app.";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_settings);

        goalWeightText = findViewById(R.id.goalWeightText);
        dateUpdateText = findViewById(R.id.dateUpdateText);
        weightUpdateText = findViewById(R.id.weightUpdateText);
        dateDeleteText = findViewById(R.id.dateDeleteText);
        Button goalButton = findViewById(R.id.goalButton);
        Button updateButton = findViewById(R.id.updateButton);
        Button deleteButton = findViewById(R.id.deleteButton);
        smsRequest = findViewById(R.id.smsRequest);
        sendSMS = findViewById(R.id.SendSMS);

        // Initialize DB
        dbWeightLog = new WeightDatabase(this);

        goalButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                inputGoal();
            }
        });

        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                updateWeight();
            }
        });

        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                deleteWeight();
            }
        });

        // Check if permission
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            sendSMS.setVisibility(View.VISIBLE);
        }

        // Request SMS permission
        smsRequest.setOnClickListener(v -> requestPermissions());

        // Send SMS
        sendSMS.setOnClickListener(v -> send_SMS());
    }

    private void inputGoal() {
        String weight_String = goalWeightText.getText().toString();

        if (weight_String.isEmpty()) {
            Toast.makeText(this, "Entry cannot be empty", Toast.LENGTH_SHORT).show();
            return;
        }

        // change weight to int
        int weight_goal = Integer.parseInt(weight_String);
        boolean goalInsert = dbWeightLog.setGoalWeight(weight_goal);

        // feedback messages for input
        if (goalInsert) {
            Toast.makeText(Settings.this, "Weight Added!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(Settings.this, "Error", Toast.LENGTH_SHORT).show();
        }
    }



    private void updateWeight() {
        String date = dateUpdateText.getText().toString().trim();
        String weight_String = weightUpdateText.getText().toString().trim();

        // change weight to int
        int weight_num = Integer.parseInt(weight_String);
        dbWeightLog.updateWeight(date, weight_num);

        Toast.makeText(Settings.this, "Weight Updated!", Toast.LENGTH_SHORT).show();
        onBackClick();
    }

    private void deleteWeight() {
        String date = dateDeleteText.getText().toString().trim();

        dbWeightLog.deleteWeight(date);

        Toast.makeText(Settings.this, "Weight Deleted!", Toast.LENGTH_SHORT).show();
        onBackClick();
    }

    private void requestPermissions() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_permission);
        } else {
            Toast.makeText(Settings.this, "Permission Granted!", Toast.LENGTH_SHORT).show();
            sendSMS.setVisibility(View.VISIBLE);
        }
    }

    //Handle permission request
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_permission) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission Granted!", Toast.LENGTH_SHORT).show();
                sendSMS.setVisibility(View.VISIBLE);
            } else {
                Toast.makeText(this, "Permission Denied!", Toast.LENGTH_SHORT).show();
                sendSMS.setVisibility(View.GONE);
            }
        }
    }

    // Send SMS to a phone number
    private void send_SMS() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNum, null, message, null, null);
            Toast.makeText(this, "SMS Sent!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Permission denied!", Toast.LENGTH_SHORT).show();
        }
    }

    //
    public void onBackClick() {
        Intent intent = new Intent(Settings.this, HomeScreen.class);
        startActivity(intent);
    }
}